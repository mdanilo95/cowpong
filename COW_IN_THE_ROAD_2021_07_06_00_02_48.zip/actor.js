//     VÁRIÁVEIS PERSONAGEM
let hit = false
let yActor = 365
let xActor = 100

//        MOSTRAR ATOR.

function showActor(){
  image(cowPlayer, xActor, yActor, 25, 25)
}

//      MOVE ACTOR

function moveActor(){
  if (keyIsDown(UP_ARROW)){
    yActor -= 2
  }  
  if (keyIsDown(DOWN_ARROW)){
    yActor += 2
  }
  if (keyIsDown(LEFT_ARROW)){
    xActor -= 2
  }
  if (keyIsDown(RIGHT_ARROW)){
    xActor += 2
  }
}

function showNigg(){
  image(neguinha, 100, 8, 25, 25)
  image(cigar,125, 8, 25 ,25)
}


function verifyColision(){
  for (let i = 0; i < carsImage.length; i = i + 1){
    hit = collideRectCircle(xCars[i], yCars[i], 45, 35, xActor, yActor, 12.5)
  if (hit){
    xActor = 100
    yActor = 365
    console.log("YOU DIE!!!")
    colisionSound.play()
    }
  }
}

function winner(){
  if (yActor < 6){
    winSound.play()
    console.log("YOU WIN!")
    yActor = 365
    xActor = 100
  }
}
                          

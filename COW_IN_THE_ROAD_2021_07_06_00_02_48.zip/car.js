//   LISTAS.
let yCars = [40, 100, 160, 210, 270, 320]
let xCars = [600, 600, 600, 600, 600, 600]


//        MOSTRAR CARRO.
function showCar(){
  for (let i = 0; i < carsImage.length; i = i + 1){
    image(carsImage[i], xCars[i], yCars[i], 45, 35)
  }
}

//        MOVIMENTAR CARRO.
function moveCar(){
  xCars[0] -= 2.5
  xCars[1] -= 3
  xCars[2] -= 4
  xCars[3] -= 3
  xCars[4] -= 3.5
  xCars[5] -= 4.5
}

//      POSIÇÃO INICIAL CARRO.
function inicialPosition(){
  for (let i = 0; i < xCars.length; i = i + 1)
  if (endRoad(xCars[i])){
    xCars[i] = 600
  }
}

function endRoad(xx){
  return xx < -30
}

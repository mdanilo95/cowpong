// VARIABLES IMAGES.
let roadImage
let actor1Image
let actor2Image
let actor3Image
let neguinha
let cigar
let colisionSound

//  IMAGES LOADS.
function preload(){
  roadImage = loadImage("IMAGES/estrada.png")
  cowPlayer = loadImage("IMAGES/ator-1.png")
  car1Image = loadImage("IMAGES/carro-1.png")
  car2Image = loadImage("IMAGES/carro-2.png")
  car3Image = loadImage("IMAGES/carro-3.png")
  neguinha = loadImage("IMAGES/negra.jfif")
  cigar = loadImage("IMAGES/cigarro.jfif")
  carsImage = [car1Image, car2Image, car3Image, car2Image, car3Image, car1Image]
  colisionSound = loadSound("sounds/colidiu.mp3")
  winSound = loadSound("sounds/whats.ogg")
} 
